<? 
		echo $_POST["dis1"]." : ".$_POST["dis2"]; 
?>