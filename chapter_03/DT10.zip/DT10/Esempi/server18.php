<? 
	 echo rand(0, 200)/100; 
?>
